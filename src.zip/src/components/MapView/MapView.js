import React, {Component} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
  TouchableOpacity,
  PermissionsAndroid
} from 'react-native';

import {
  Header,
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';

import MapView, { PROVIDER_GOOGLE, Polyline, Marker } from 'react-native-maps';


class MapScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
          details:this.props.route.params.details,
          coords:[]
        }
     }

    componentDidMount(){
        this.initPermissions()
    }
 
    initPermissions = async() => {

        const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION);
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
            console.log('You can use the location');
        } else {
            console.log('Location permission denied');
        }
    }

 render(){
  return (
    <>
      <StatusBar barStyle="dark-content" />
      <SafeAreaView style={{flex:1}}>
       <MapView
          provider={PROVIDER_GOOGLE} // remove if not using Google Maps
          style={{width:"100%", height:"80%", marginTop:10}}
          initialRegion={{
            latitude: 23.1697748,
            longitude: 77.4421694,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
          }}
        >
          {this.state.coords.map((marker, index) => (
            <Marker
              key={index}
              coordinate={marker}
            />
          ))}
        	<Polyline
                coordinates={this.state.coords}
                strokeColor="#000" // fallback for when `strokeColors` is not supported by the map-provider
                strokeWidth={6}
            />
        </MapView>
      </SafeAreaView>
    </>
  )
 }
}

const styles = StyleSheet.create({
  scrollView: {
    backgroundColor: Colors.lighter,
  },
  engine: {
    position: 'absolute',
    right: 0,
  },
  body: {
    backgroundColor: Colors.white,
  },
  sectionContainer: {
    marginTop: 32,
    paddingHorizontal: 24,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: Colors.black,
  },
  sectionDescription: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: '400',
    color: Colors.dark,
  },
  highlight: {
    fontWeight: '700',
  },
  footer: {
    color: Colors.dark,
    fontSize: 12,
    fontWeight: '600',
    padding: 4,
    paddingRight: 12,
    textAlign: 'right',
  },
});

export default MapScreen;
